#pragma once

class CashDesk;